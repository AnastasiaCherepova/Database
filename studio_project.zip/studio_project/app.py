from flask import Flask, render_template, request, redirect, url_for
from db_config import get_db_connection

app = Flask(__name__)


@app.route('/')
def index():
    query = request.args.get('q', '')
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if query:
        cursor.execute("""
            SELECT 
                Project.ID, Project.Name, Project.Priority, Project.Genre,
                Client.FullName AS ClientName
            FROM Project
            JOIN Client ON Project.Client_ID = Client.ID
            WHERE Project.Name LIKE %s
        """, (f"%{query}%",))
    else:
        cursor.execute("""
            SELECT 
                Project.ID, Project.Name, Project.Priority, Project.Genre,
                Client.FullName AS ClientName
            FROM Project
            JOIN Client ON Project.Client_ID = Client.ID
        """)

    projects = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('index.html', projects=projects, query=query)


@app.route('/add', methods=['GET', 'POST'])
def add_project():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        name = request.form['name']
        priority = request.form['priority']
        genre = request.form['genre']

        client_id = request.form.get('client_id') or None
        new_client_name = request.form.get('new_client_name')
        new_client_contact = request.form.get('new_client_contact')

        # Если пользователь не выбрал существующего клиента, но указал нового
        if not client_id and new_client_name:
            cursor.execute(
                "INSERT INTO Client (FullName, Contact) VALUES (%s, %s)",
                (new_client_name, new_client_contact)
            )
            conn.commit()
            client_id = cursor.lastrowid

        # Добавление проекта
        cursor.execute(
            "INSERT INTO Project (Name, Priority, Genre, Client_ID) VALUES (%s, %s, %s, %s)",
            (name, priority, genre, client_id)
        )
        conn.commit()

        cursor.close()
        conn.close()
        return redirect(url_for('index'))

    # GET-запрос: отображаем форму
    cursor.execute("SELECT * FROM Client")
    clients = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('add_project.html', clients=clients)


@app.route('/edit/<int:project_id>', methods=['GET', 'POST'])
def edit_project(project_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        name = request.form['name']
        priority = request.form['priority']
        genre = request.form['genre']

        if request.form.get('new_client'):
            new_client = request.form['new_client']
            cursor.execute("INSERT INTO Client (FullName) VALUES (%s)", (new_client,))
            conn.commit()
            client_id = cursor.lastrowid
        else:
            client_id = request.form['client_id']

        cursor.execute("""
            UPDATE Project SET Name=%s, Priority=%s, Genre=%s, Client_ID=%s WHERE ID=%s
        """, (name, priority, genre, client_id, project_id))
        conn.commit()
        return redirect(url_for('index'))

    cursor.execute("SELECT * FROM Project WHERE ID = %s", (project_id,))
    project = cursor.fetchone()
    cursor.execute("SELECT * FROM Client")
    clients = cursor.fetchall()
    return render_template('edit_project.html', project=project, clients=clients)

@app.route('/delete/<int:project_id>')
def delete_project(project_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Project WHERE ID = %s", (project_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('index'))

@app.route('/sessions')
def sessions():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT Session.ID, Session.Date, Session.Duration, Project.Name AS ProjectName
        FROM Session
        JOIN Project ON Session.Project_ID = Project.ID
        ORDER BY Session.Date DESC
    """)
    sessions = cursor.fetchall()
    return render_template('sessions.html', sessions=sessions)

@app.route('/actors')
def actors():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT Actor.ID, Actor.FullName, Actor.Role, Studio.Name AS StudioName
        FROM Actor
        JOIN Studio ON Actor.Studio_ID = Studio.ID
    """)
    actors = cursor.fetchall()
    return render_template('actors.html', actors=actors)

@app.route('/analytics/projects_per_client')
def projects_per_client():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT Client.FullName, COUNT(Project.ID) AS ProjectCount
        FROM Client
        LEFT JOIN Project ON Client.ID = Project.Client_ID
        GROUP BY Client.ID
        ORDER BY ProjectCount DESC
    """)
    data = cursor.fetchall()
    return render_template('analytics_projects_per_client.html', data=data)

@app.route('/analytics/avg_session_duration')
def avg_session_duration():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT 
            Project.Name AS ProjectName,
            AVG(Session.Duration) AS AvgDuration
        FROM Session
        JOIN Project ON Session.Project_ID = Project.ID
        GROUP BY Project.ID
        ORDER BY AvgDuration DESC
    """)
    data = cursor.fetchall()
    return render_template('analytics_avg_session_duration.html', data=data)


@app.route('/delete_client/<int:client_id>')
def delete_client(client_id):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Проверим, есть ли связанные проекты
    cursor.execute("SELECT COUNT(*) FROM Project WHERE Client_ID = %s", (client_id,))
    count = cursor.fetchone()[0]

    if count > 0:
        # Если есть проекты, не удаляем
        return "Невозможно удалить клиента: есть связанные проекты."

    # Если нет связанных проектов — удаляем
    cursor.execute("DELETE FROM Client WHERE ID = %s", (client_id,))
    conn.commit()
    return redirect(url_for('clients'))  # Предполагаем, что есть страница /clients

@app.route('/clients')
def clients():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Client")
    clients = cursor.fetchall()
    return render_template('clients.html', clients=clients)


if __name__ == '__main__':
    app.run(debug=True)
